package cn.peterchen.imtest.xmpp.facade;

public abstract class XmppCallBack {

}
