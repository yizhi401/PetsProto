package cn.peterchen.imtest.xmpp.facade;

/**
 * Offers the xmpp basic function:
 * init xmpp service
 * Login/Logout
 * Change User
 * Send Message
 * Receive Message
 * @author peter
 *
 */
public class XmppFacade {
	
	

}
