package cn.peterchen.imtest.xmpp.facade;

public interface XmppListener {

}
