package cn.peterchen.imtest.xmpp.facade;

public class XmppChatListener {

}
