package cn.peterchen.imtest.ui;

import java.util.Date;
import java.util.List;

import android.content.Context;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import cn.peterchen.imtest.R;
import cn.peterchen.imtest.xmpp.core.XmppMsg;


public class ChatAdapter extends BaseAdapter {

	private static final String DATE_FORMAT = "yyyy-MM-dd hh:mm:ss";
	private final List<XmppMsg> chatMessages;
	private Context context;

	public ChatAdapter(Context context, List<XmppMsg> chatMessages) {
		this.context = context;
		this.chatMessages = chatMessages;
	}

	@Override
	public int getCount() {
		if (chatMessages != null) {
			return chatMessages.size();
		} else {
			return 0;
		}
	}

	@Override
	public XmppMsg getItem(int position) {
		if (chatMessages != null) {
			return chatMessages.get(position);
		} else {
			return null;
		}
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		XmppMsg chatMessage = getItem(position);
		LayoutInflater vi = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		if (convertView == null) {
			convertView = vi.inflate(R.layout.list_item_message, null);
			holder = createViewHolder(convertView);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		setAlignment(holder, chatMessage.isIncoming());
		holder.txtMessage.setText(chatMessage.generateFmtTxt());

		return convertView;
	}

	public void add(XmppMsg message) {
		chatMessages.add(message);
	}

	public void add(List<XmppMsg> messages) {
		chatMessages.addAll(messages);
	}

	private void setAlignment(ViewHolder holder, boolean isIncoming) {
		if (isIncoming) {
			holder.contentWithBG
					.setBackgroundResource(R.drawable.incoming_message_bg);

			LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) holder.contentWithBG
					.getLayoutParams();
			layoutParams.gravity = Gravity.RIGHT;
			holder.contentWithBG.setLayoutParams(layoutParams);

			RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) holder.content
					.getLayoutParams();
			lp.addRule(RelativeLayout.ALIGN_PARENT_LEFT, 0);
			lp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
			holder.content.setLayoutParams(lp);
			layoutParams = (LinearLayout.LayoutParams) holder.txtMessage
					.getLayoutParams();
			layoutParams.gravity = Gravity.RIGHT;
			holder.txtMessage.setLayoutParams(layoutParams);

			layoutParams = (LinearLayout.LayoutParams) holder.txtInfo
					.getLayoutParams();
			layoutParams.gravity = Gravity.RIGHT;
			holder.txtInfo.setLayoutParams(layoutParams);
		} else {
			holder.contentWithBG
					.setBackgroundResource(R.drawable.outgoing_message_bg);

			LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) holder.contentWithBG
					.getLayoutParams();
			layoutParams.gravity = Gravity.LEFT;
			holder.contentWithBG.setLayoutParams(layoutParams);

			RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) holder.content
					.getLayoutParams();
			lp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, 0);
			lp.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
			holder.content.setLayoutParams(lp);
			layoutParams = (LinearLayout.LayoutParams) holder.txtMessage
					.getLayoutParams();
			layoutParams.gravity = Gravity.LEFT;
			holder.txtMessage.setLayoutParams(layoutParams);

			layoutParams = (LinearLayout.LayoutParams) holder.txtInfo
					.getLayoutParams();
			layoutParams.gravity = Gravity.LEFT;
			holder.txtInfo.setLayoutParams(layoutParams);
		}
	}

	private ViewHolder createViewHolder(View v) {
		ViewHolder holder = new ViewHolder();
		holder.txtMessage = (TextView) v.findViewById(R.id.txtMessage);
		holder.content = (LinearLayout) v.findViewById(R.id.content);
		holder.contentWithBG = (LinearLayout) v
				.findViewById(R.id.contentWithBackground);
		holder.txtInfo = (TextView) v.findViewById(R.id.txtInfo);
		return holder;
	}

	private String getTimeText(Date date) {
		return DateFormat.format(DATE_FORMAT, date).toString();
	}

	private static class ViewHolder {
		public TextView txtMessage;
		public TextView txtInfo;
		public LinearLayout content;
		public LinearLayout contentWithBG;
	}
}
